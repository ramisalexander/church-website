
const navbar = document.getElementsByClassName("navbar");
const logo =  document.getElementsByClassName("logo");

// console.log(navbar[0].children[0].children[1].children[0]);

// let i;
// for(let i = 1; i< 7; i++){
//     // console.log(i)
//     console.log(navbar[0].children[0].children[i].children[0]);

// }

// console.log(logo[0].children[0].style.width = "90%");
// navbar[0]
window.addEventListener("scroll", () => {


    if (document.documentElement.scrollTop > 10) {
        // alert("Hello");
        navbar[0].style.width = "100%";
        navbar[0].style.borderRadius = "0";
        navbar[0].style.position = "sticky";
        navbar[0].style.top = "0";
        navbar[0].style.margin = "0";
        navbar[0].style.backgroundColor = "#F1E7D9";
        logo[0].children[0].style.width = "90%";
        
        // navbar[0].children[0].children[1].children[0].style.color = "red";
        for(let i = 1; i< 7; i++){
            // console.log(i)
            navbar[0].children[0].children[i].children[0].style.color="black";  
        }
        // document.getElementById().style.opacity = "1";
        // document.querySelector(".main-heading").style.opacity = "1";
        // document.querySelector(".shot-heading").style.opacity = "1";
        // document.querySelector(".short-para").style.opacity = "1";
        // document.querySelector(".long-para").style.opacity = "1";
        // navbar[0].style.opacity = 1;
    }else{
        navbar[0].style.width = null;
        navbar[0].style.borderRadius = null;
        navbar[0].style.position = null;
        navbar[0].style.top = null;
        navbar[0].style.margin = null;
        navbar[0].style.backgroundColor = null;
        logo[0].children[0].style.width = null;


        for(let i = 1; i< 7; i++){
            // console.log(i)
            navbar[0].children[0].children[i].children[0].style.color=null;  
        }

    }
    // document.getElementById().style.position= ""
    // if(navbar[0].scrollTop > 10){
    //     alert("Hello")
    // }
});


const burger =  document.getElementsByClassName("hamburger");
burger[0].addEventListener("click", function(){
    // navList.classList.toggle('v-class-resp');
    // rightNav.classList.toggle('v-class-resp');
    // logo.classList.toggle("v-class-resp");
    navbar[0].classList.toggle('h-nav-resp');
    document.getElementById("myUL").classList.toggle("v-nav-resp");


});
// document.querySelector(".hamburger").addEventListener("click", ()=>{
//     // navbar[0].classList.add("h-nav-resp");
//     navbar[0].classList.toggle("h-nav-resp");
//     navbar[0].classList.toggle("v-nav-resp");

// })